import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class CreateCXMLStructure {

	Document dom;
	Element rootEle;
	Element e = null;
	Element r = null;

	DocumentBuilderFactory dbf;
	DocumentBuilder db;
	String outputFileName;

	public CreateCXMLStructure(String outputFileName, String rootNode) {

		dbf = DocumentBuilderFactory.newInstance();
		this.outputFileName = outputFileName;
		try {
			// use factory to get an instance of document builder
			db = dbf.newDocumentBuilder();
			// create instance of DOM
			dom = db.newDocument();
			rootEle = dom.createElement(rootNode);
			dom.appendChild(rootEle);
		} catch (Exception e) {
		}
	}

	public void createNode(String parentNodeName, String childNodeName) throws FileNotFoundException {

		try{
			if (dom.getElementsByTagName(parentNodeName) != null) 
			{
				e = dom.createElement(childNodeName);
				NodeList r = dom.getElementsByTagName(parentNodeName);
				Node node = r.item(0);
				Element em = (Element)node;
				//e.appendChild(dom.createTextNode("Test Text"));
				em.appendChild(e);
				//rootEle.appendChild(em);
			} else {
				r = dom.createElement(parentNodeName);
				//r.appendChild(dom.createTextNode("Text Test"));
				rootEle.appendChild(r);
				e =  dom.createElement(childNodeName);
				//e.appendChild(dom.createTextNode("Test Text"));
				r.appendChild(e);
			}
		}catch(Exception e){
			System.out.println(e.getMessage());
		}


		try

		{
			Transformer tr = TransformerFactory.newInstance().newTransformer();
			tr.setOutputProperty(OutputKeys.INDENT, "yes");
			tr.setOutputProperty(OutputKeys.METHOD, "xml");
			tr.setOutputProperty(OutputKeys.ENCODING, "UTF-16");
			tr.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "roles.dtd");
			tr.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");

			// send DOM to file
			tr.transform(new DOMSource(dom), new StreamResult(new FileOutputStream(outputFileName)));

		} catch (TransformerException te) {
			System.out.println(te.getMessage());
		}
	}
}
