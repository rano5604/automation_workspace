import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.bind.DatatypeConverter;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class ReadXMLReport {
	static String LicenseNoEn;
	static String ReferenceNo;
	static String NameEn;
	static String ChipSerialNo;
	static String ChipSequenceNo;
	static String BirthDateEn;
	static int count = 0;
	static String number;


	public static void main(String argv[]) {
		try {
			// creating a constructor of file class and parsing an XML file
			File file = new File(".\\Report_93312_39885_2022_05_23_07_08_23.xml");
			// an instance of factory that gives a document builder
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			// an instance of builder to parse the specified xml file
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(file);
			doc.getDocumentElement().normalize();
			System.out.println("Root element: " + doc.getDocumentElement().getNodeName());
			NodeList nodeList = doc.getElementsByTagName("DataFields");
			SaveToXML xml = new SaveToXML("c.xml");
			
			StructureFinder sc = new StructureFinder();
			List<String> parameter= sc.ParameterList(".\\output1.xml");
			
			Map<String, String> dict = new HashMap<>();
			
			for (int itr = 1; itr < nodeList.getLength(); itr++) {
				Node node = nodeList.item(itr);
				System.out.println(itr);
				System.out.println("\nNode Name :" + node.getNodeName());
				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element eElement = (Element) node;

					NodeList cNodeList = eElement.getElementsByTagName("DataField");

				
					for (int citr = 0; citr < cNodeList.getLength(); citr++) {
						Node c = cNodeList.item(citr);
						NamedNodeMap attributes = c.getAttributes();
						Node attr = attributes.getNamedItem("Name");
						if (attr != null) {
							
							for (int i=0;i<parameter.size();i++){
								if (attr.getTextContent().contains(parameter.get(i))) {
									String name = (String) parameter.get(i);
									if (c.getTextContent()!=null){
										dict.put(name, hexToAscii(c.getTextContent()));
									}
									
									//byte[] BirthDateEnHex = c.getTextContent().getBytes();
									//BirthDateEn = hexToAscii(BirthDateEnHex);
									//System.out.println(BirthDateEn);
								}
							}
						}
					}
					System.out.println(dict);
					//number = Integer.toString(count++);
					//xml.addElement(LicenseNoEn, number, ChipSequenceNo, ChipSerialNo, ReferenceNo, NameEn, BirthDateEn);

				}

			}


		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static String hexToAscii(String data) {
		String newString = new String(data);
		StringBuilder output = new StringBuilder("");
		

		for (int i = 0; i < newString.length(); i += 2) {
			String str = newString.substring(i, i + 2);
			output.append((char) Integer.parseInt(str, 16));

		}
		return output.toString().toString();
	}

}